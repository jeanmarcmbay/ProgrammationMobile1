class CardFlipActivity : FragmentActivity() {

    ...

    private fun flipCard() {
        if (showingBack) {
            supportFragmentManager.popBackStack()
            return
        }

        

        showingBack = true



        supportFragmentManager.beginTransaction()


                .setCustomAnimations(
                        R.animator.card_flip_right_in,
                        R.animator.card_flip_right_out,
                        R.animator.card_flip_left_in,
                        R.animator.card_flip_left_out
                )


                .replace(R.id.container, CardBackFragment())

                .addToBackStack(null)


                .commit()
    }
}
