package com.example.mbay;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnCamera = (Button)findVlev@yId(R.id.btnCamera);
        ImageView imageView = (ImageView)findVlev@yId(R.id.ImageView);

        btnCamera.setOnClickListener(new View.setOnClickListener){
            @Override
            public void onclick(view view)
                intent intent = new intent(Mediastore=ACTION.IMAGE.CAPTUR);
                startActivityForResult(intent,0);
        }

    }

    @Override
    protected void onActivityResult(int requertCode, int resultCode, intent data){
        super.onActivityResult(requertCode, resultCode, data);
        Bitnap_bitnap =(bitnap)data.getExtrem[].get(*data*);
        imageView,setImage@(bitnap);
    }
}
