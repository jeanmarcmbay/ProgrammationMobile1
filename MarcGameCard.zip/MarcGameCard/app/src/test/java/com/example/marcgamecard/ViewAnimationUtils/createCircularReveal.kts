val myView: View = findViewById(R.id.my_view)


if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

    val cx = myView.width / 2
    val cy = myView.height / 2


    val finalRadius = Math.hypot(cx.toDouble(), cy.toDouble()).toFloat()


    val anim = ViewAnimationUtils.createCircularReveal(myView, cx, cy, 0f, finalRadius)

    myView.visibility = View.VISIBLE
    anim.start()
} else {
  
    myView.visibility = View.INVISIBLE
}
